//
//  ViewController.swift
//  Imagen
//
//  Created by Alumno on 9/13/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblTitulo: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func DoTapdoggo(_ sender: Any) {
        lblTitulo.text = "Le diste tap al perro"
    }
    
}

